'use client';

/**
 * BURKA OS - The Bro Split 2.0
 * Architecture:
 * 1. Domain Layer (Pure TS, Logic, Progression, Definitions)
 * 2. Persistence Layer (Dexie, Zod Schemas)
 * 3. Application Layer (Zustand State Machine)
 * 4. UI Layer (React, Tailwind, Recharts)
 */

import React, { useState, useEffect, useMemo } from 'react';
import Dexie, { Table } from 'dexie';
import { create } from 'zustand';
import { z } from 'zod';
import { 
  Play, Square, Save, Settings, History, 
  Dumbbell, ChevronRight, Trash2, CheckCircle, 
  Clock, Download, Upload, Info, Youtube
} from 'lucide-react';
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

// ============================================================================
// 1. DOMAIN LAYER (Pure Logic & Program Data)
// ============================================================================

export type MuscleGroup = 'Chest' | 'Back' | 'Quads' | 'Hamstrings' | 'Calves' | 'Shoulders' | 'Triceps' | 'Biceps' | 'Core';

export interface ExerciseDefinition {
  id: string;
  name: string;
  muscleGroups: MuscleGroup[];
  defaultTempo: string;
  aliases: string[];
}

export interface SetTemplate {
  minSets: number;
  maxSets: number;
  minReps: number | 'AMRAP';
  maxReps: number | 'AMRAP';
  type: 'Straight' | 'RPS' | 'Alternating' | 'AMRAP';
  tempo: string;
}

export interface ProgramExercise {
  definitionId: string;
  template: SetTemplate;
  notes?: string;
  supersetId?: string;
}

export interface ProgramDay {
  id: string;
  name: string;
  priorityMuscles: MuscleGroup[];
  exercises: ProgramExercise[];
  isRest?: boolean;
}

// The Bro Split 2.0 Data Seed (partial seed based on current code)
const BURKA_EXERCISES: Record<string, ExerciseDefinition> = {
  'chest_fly': { id: 'chest_fly', name: 'Seated Chest Fly Variation', muscleGroups: ['Chest'], defaultTempo: '3-1-1-2', aliases: ['Pec Deck', 'Cable Fly'] },
  'incline_press': { id: 'incline_press', name: 'Incline Press Movement', muscleGroups: ['Chest', 'Shoulders', 'Triceps'], defaultTempo: '3-1-1-1', aliases: ['Incline DB Press', 'Incline Smith'] },
  'flat_press': { id: 'flat_press', name: 'Flat / Decline Press', muscleGroups: ['Chest', 'Triceps'], defaultTempo: '3-1-1-1', aliases: ['Flat Machine Press', 'Decline Press'] },
  'rope_pushdown': { id: 'rope_pushdown', name: 'Cable Rope Pushdown', muscleGroups: ['Triceps'], defaultTempo: '3-1-1-1', aliases: ['Tricep Pushdown'] },
  'skull_crushers': { id: 'skull_crushers', name: 'Skull Crushers', muscleGroups: ['Triceps'], defaultTempo: '3-1-1-1', aliases: ['EZ-Bar Skullcrusher'] },
  'lateral_raise': { id: 'lateral_raise', name: 'Lateral Raise Variation', muscleGroups: ['Shoulders'], defaultTempo: '3-1-1-1', aliases: ['DB Lateral Raise', 'Cable Lateral Raise'] },
  'sagittal_pull': { id: 'sagittal_pull', name: 'Sagittal Pull Movement', muscleGroups: ['Back'], defaultTempo: '3-1-1-2', aliases: ['Single Arm Pulldown', 'Cable Pullover'] },
  'lat_row': { id: 'lat_row', name: 'Lat Focused Row', muscleGroups: ['Back'], defaultTempo: '3-1-1-2', aliases: ['Chest Supported Row'] },
  'assisted_pullup': { id: 'assisted_pullup', name: 'Wide Grip Assisted Pull Ups', muscleGroups: ['Back'], defaultTempo: '3-1-1-2', aliases: ['Pullups'] },
  'upper_back_row': { id: 'upper_back_row', name: 'Upper Back Focused Row', muscleGroups: ['Back', 'Shoulders'], defaultTempo: '3-1-1-1', aliases: ['T-Bar Row', 'Pronated Row'] },
  'supinated_curl': { id: 'supinated_curl', name: 'Bilateral Supinated Curl', muscleGroups: ['Biceps'], defaultTempo: '3-2-1-2', aliases: ['Barbell Curl'] },
  'hammer_curl': { id: 'hammer_curl', name: 'Alt DB Hammer Curl', muscleGroups: ['Biceps'], defaultTempo: '3-1-1-1', aliases: ['Hammer Curls'] },
  'rear_delt_fly': { id: 'rear_delt_fly', name: 'Rear Delt Fly Variation', muscleGroups: ['Shoulders', 'Back'], defaultTempo: '3-1-1-1', aliases: ['Reverse Pec Deck'] },
  'seated_leg_curl': { id: 'seated_leg_curl', name: 'Seated Leg Curl Machine', muscleGroups: ['Hamstrings'], defaultTempo: '4-1-1-2', aliases: ['Hamstring Curl'] },
  'leg_extension': { id: 'leg_extension', name: 'Leg Extension Machine', muscleGroups: ['Quads'], defaultTempo: '4-1-1-2', aliases: ['Quad Extension'] },
  'rfe_split_squat': { id: 'rfe_split_squat', name: 'Rear Foot Elevated Split Squat', muscleGroups: ['Quads'], defaultTempo: '3-2-1-1', aliases: ['Bulgarian Split Squat'] },
  'hip_adduction': { id: 'hip_adduction', name: 'Seated Hip Adduction', muscleGroups: ['Quads'], defaultTempo: '4-2-1-2', aliases: ['Adductor Machine'] },
  'quad_squat': { id: 'quad_squat', name: 'Quad Focused Squat', muscleGroups: ['Quads'], defaultTempo: '4-1-1-1', aliases: ['Hack Squat', 'Front Squat'] },
  'calf_raise': { id: 'calf_raise', name: 'Straight Leg Calf Raise', muscleGroups: ['Calves'], defaultTempo: '3-3-1-2', aliases: ['Standing Calf Raise'] },
  'side_delt': { id: 'side_delt', name: 'Side Delt Movement', muscleGroups: ['Shoulders'], defaultTempo: '3-1-1-1', aliases: ['Upright Row'] },
  'overhead_press': { id: 'overhead_press', name: 'Overhead Press Movement', muscleGroups: ['Shoulders', 'Triceps'], defaultTempo: '3-1-1-1', aliases: ['DB Shoulder Press'] },
  'cable_extension': { id: 'cable_extension', name: 'Tricep Cable Extension', muscleGroups: ['Triceps'], defaultTempo: '3-1-1-2', aliases: ['Cross Body Extension'] },
  'preacher_curl': { id: 'preacher_curl', name: 'Preacher Curls', muscleGroups: ['Biceps'], defaultTempo: '3-1-1-2', aliases: ['Machine Preacher'] },
  'close_grip_press': { id: 'close_grip_press', name: 'Close Grip Press', muscleGroups: ['Triceps', 'Chest'], defaultTempo: '3-1-1-1', aliases: ['Close Grip Bench'] },
  'alt_db_curl': { id: 'alt_db_curl', name: 'Alt DB Curls - Supination Bias', muscleGroups: ['Biceps'], defaultTempo: '3-1-1-1', aliases: ['DB Curl'] },
  'lying_pullover': { id: 'lying_pullover', name: 'Lying DB Pullovers', muscleGroups: ['Chest', 'Back'], defaultTempo: '4-2-1-1', aliases: ['DB Pullover'] },
  'reverse_curl': { id: 'reverse_curl', name: 'Reverse Curls', muscleGroups: ['Biceps'], defaultTempo: '3-1-1-1', aliases: ['Pronated Curl'] },
  'lat_pulldown': { id: 'lat_pulldown', name: 'Lat Pulldown', muscleGroups: ['Back'], defaultTempo: '3-1-1-1', aliases: ['Neutral Grip Pulldown'] },
  'leg_curl_var': { id: 'leg_curl_var', name: 'Leg Curl Variation', muscleGroups: ['Hamstrings'], defaultTempo: '4-1-1-2', aliases: ['Lying Leg Curl'] },
  'hip_hinge': { id: 'hip_hinge', name: 'Hip Hinge', muscleGroups: ['Hamstrings', 'Back'], defaultTempo: '4-2-1-1', aliases: ['RDL', 'Good Morning'] },
  'leg_press': { id: 'leg_press', name: 'Narrow Stance Leg Press', muscleGroups: ['Quads'], defaultTempo: '4-1-1-1', aliases: ['Leg Press'] },
};

const BRO_SPLIT_DAYS: ProgramDay[] = [
  { id: 'day_1', name: 'Day 1: Chest Priority', priorityMuscles: ['Chest'], exercises: [
    { definitionId: 'chest_fly', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-2' } },
    { definitionId: 'incline_press', template: { minSets: 1, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'flat_press', template: { minSets: 1, maxSets: 2, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'rope_pushdown', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'skull_crushers', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'lateral_raise', template: { minSets: 2, maxSets: 4, minReps: 8, maxReps: 15, type: 'Straight', tempo: '3-1-1-1' } },
  ]},
  { id: 'day_2', name: 'Day 2: Back Priority', priorityMuscles: ['Back'], exercises: [
    { definitionId: 'sagittal_pull', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-2' } },
    { definitionId: 'lat_row', template: { minSets: 2, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-2' } },
    { definitionId: 'assisted_pullup', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-2' } },
    { definitionId: 'upper_back_row', template: { minSets: 2, maxSets: 3, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'supinated_curl', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-2-1-2' } },
    { definitionId: 'hammer_curl', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'rear_delt_fly', template: { minSets: 2, maxSets: 4, minReps: 8, maxReps: 15, type: 'Straight', tempo: '3-1-1-1' } },
  ]},
  { id: 'day_3', name: 'Day 3: Quad Priority', priorityMuscles: ['Quads'], exercises: [
    { definitionId: 'seated_leg_curl', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '4-1-1-2' } },
    { definitionId: 'leg_extension', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'Straight', tempo: '4-1-1-2' } },
    { definitionId: 'rfe_split_squat', template: { minSets: 1, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-2-1-1' } },
    { definitionId: 'hip_adduction', template: { minSets: 1, maxSets: 1, minReps: 10, maxReps: 15, type: 'RPS', tempo: '4-2-1-2' } },
    { definitionId: 'quad_squat', template: { minSets: 1, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '4-1-1-1' } },
    { definitionId: 'calf_raise', template: { minSets: 2, maxSets: 5, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-3-1-2' } },
  ]},
  { id: 'day_4', name: 'Day 4: Rest', priorityMuscles: [], exercises: [], isRest: true },
  { id: 'day_5', name: 'Day 5: Delts + Arms', priorityMuscles: ['Shoulders', 'Triceps', 'Biceps'], exercises: [
    { definitionId: 'rear_delt_fly', template: { minSets: 2, maxSets: 4, minReps: 8, maxReps: 15, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'side_delt', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'RPS', tempo: '3-1-1-1' }, notes: "1 Straight + 1 RPS" },
    { definitionId: 'overhead_press', template: { minSets: 1, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'cable_extension', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'RPS', tempo: '3-1-1-2' } },
    { definitionId: 'preacher_curl', template: { minSets: 2, maxSets: 2, minReps: 8, maxReps: 12, type: 'RPS', tempo: '3-1-1-2' } },
    { definitionId: 'close_grip_press', template: { minSets: 2, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'alt_db_curl', template: { minSets: 2, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'lying_pullover', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 15, type: 'Alternating', tempo: '4-2-1-1' }, supersetId: 'arm_alt_1' },
    { definitionId: 'reverse_curl', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 15, type: 'Alternating', tempo: '3-1-1-1' }, supersetId: 'arm_alt_1' },
  ]},
  { id: 'day_6', name: 'Day 6: Back + Legs', priorityMuscles: ['Back', 'Hamstrings', 'Quads'], exercises: [
    { definitionId: 'upper_back_row', template: { minSets: 2, maxSets: 3, minReps: 6, maxReps: 10, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'lat_pulldown', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-1-1-1' } },
    { definitionId: 'leg_curl_var', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '4-1-1-2' } },
    { definitionId: 'hip_hinge', template: { minSets: 2, maxSets: 2, minReps: 6, maxReps: 10, type: 'Straight', tempo: '4-2-1-1' } },
    { definitionId: 'leg_press', template: { minSets: 2, maxSets: 3, minReps: 8, maxReps: 12, type: 'Straight', tempo: '4-1-1-1' } },
    { definitionId: 'calf_raise', template: { minSets: 2, maxSets: 5, minReps: 8, maxReps: 12, type: 'Straight', tempo: '3-3-1-2' } },
  ]},
  { id: 'day_7', name: 'Day 7: Rest', priorityMuscles: [], exercises: [], isRest: true },
];

export const ProgressionEngine = {
  analyzeSet: (reps: number, targetMax: number | 'AMRAP', targetMin: number | 'AMRAP', isFailure: boolean) => {
    if (targetMax === 'AMRAP' || targetMin === 'AMRAP') return { action: 'MAINTAIN', reason: 'AMRAP set logged.' };
    if (reps > targetMax) return { action: 'INCREASE', reason: `Exceeded top of rep range (${targetMax}). Progressive overload achieved.` };
    if (reps >= targetMax && isFailure) return { action: 'INCREASE', reason: `Hit top of rep range to failure. Ready to increase load.` };
    if (reps < targetMin) return { action: 'DECREASE', reason: `Fell below target floor (${targetMin}). Consider a 10-20% drop.` };

    const midpoint = targetMin + ((targetMax - targetMin) / 2);
    if (reps < midpoint && isFailure) return { action: 'BACK_OFF', reason: `Failed below midpoint (${midpoint}). Drop weight 10-20% for next set to maintain range.` };

    return { action: 'MAINTAIN', reason: 'Within target range. Keep pushing.' };
  },
  calculatePlates: (totalWeight: number, barWeight = 45, availablePlates = [45, 35, 25, 10, 5, 2.5]) => {
    let perSide = (totalWeight - barWeight) / 2;
    if (perSide <= 0) return [];
    const platesUsed: number[] = [];
    for (const plate of availablePlates.sort((a,b) => b-a)) {
      while (perSide >= plate) {
        platesUsed.push(plate);
        perSide -= plate;
      }
    }
    return platesUsed;
  }
};

// ============================================================================
// 2. PERSISTENCE LAYER (Dexie DB & Zod Validation)
// ============================================================================

export interface WorkoutSet {
  id: string;
  weight: number;
  reps: number;
  rir?: number;
  isFailure: boolean;
  isBackOff: boolean;
  type: 'Straight' | 'RPS' | 'Alternating' | 'AMRAP' | 'Warmup';
  rpsRounds?: { reps: number }[];
  timestamp: number;
}

export interface WorkoutExercise {
  id: string;
  definitionId: string;
  templateSnapshot: SetTemplate;
  sets: WorkoutSet[];
}

export interface WorkoutSession {
  id: string;
  dayId: string;
  dayName: string;
  startedAt: number;
  finishedAt: number | null;
  isDraft: boolean;
  exercises: WorkoutExercise[];
}

export interface Settings {
  id: string;
  unit: 'lbs' | 'kg';
  youtubeApiKey?: string;
}

export interface VideoMapping {
  definitionId: string;
  videoId: string;
  title: string;
  thumbnail: string;
}

class BurkaDatabase extends Dexie {
  sessions!: Table<WorkoutSession, string>;
  settings!: Table<Settings, string>;
  videoMappings!: Table<VideoMapping, string>;

  constructor() {
    super('BurkaOS_DB');
    this.version(1).stores({
      sessions: 'id, dayId, isDraft, startedAt',
      settings: 'id',
      videoMappings: 'definitionId'
    });
  }
}

const db = new BurkaDatabase();

const ExportSchema = z.object({
  version: z.number(),
  sessions: z.array(z.any()),
  settings: z.array(z.any()),
  videoMappings: z.array(z.any())
});

// ============================================================================
// 3. APPLICATION LAYER (Zustand State Machine)
// ============================================================================

interface AppState {
  view: 'HOME' | 'WORKOUT' | 'HISTORY' | 'SETTINGS';
  activeSession: WorkoutSession | null;
  restTimer: { active: boolean; endsAt: number; durationSec: number } | null;

  setView: (view: 'HOME' | 'WORKOUT' | 'HISTORY' | 'SETTINGS') => void;
  startSession: (day: ProgramDay) => Promise<void>;
  resumeSession: (session: WorkoutSession) => void;
  endSession: () => Promise<void>;
  cancelSession: () => Promise<void>;

  logSet: (exerciseId: string, set: WorkoutSet) => Promise<void>;
  deleteSet: (exerciseId: string, setId: string) => Promise<void>;

  startRest: (seconds: number) => void;
  stopRest: () => void;
}

const generateId = () => Math.random().toString(36).substring(2, 9);

const useStore = create<AppState>((set, get) => ({
  view: 'HOME',
  activeSession: null,
  restTimer: null,

  setView: (view) => set({ view }),

  startSession: async (day) => {
    const newSession: WorkoutSession = {
      id: generateId(),
      dayId: day.id,
      dayName: day.name,
      startedAt: Date.now(),
      finishedAt: null,
      isDraft: true,
      exercises: day.exercises.map(e => ({
        id: generateId(),
        definitionId: e.definitionId,
        templateSnapshot: e.template,
        sets: []
      }))
    };
    await db.sessions.put(newSession);
    set({ activeSession: newSession, view: 'WORKOUT' });
  },

  resumeSession: (session) => {
    set({ activeSession: session, view: 'WORKOUT' });
  },

  endSession: async () => {
    const { activeSession } = get();
    if (!activeSession) return;
    const completed = { ...activeSession, finishedAt: Date.now(), isDraft: false };
    await db.sessions.put(completed);
    set({ activeSession: null, view: 'HISTORY', restTimer: null });
  },

  cancelSession: async () => {
    const { activeSession } = get();
    if (!activeSession) return;
    await db.sessions.delete(activeSession.id);
    set({ activeSession: null, view: 'HOME', restTimer: null });
  },

  logSet: async (exerciseId, workoutSet) => {
    const { activeSession } = get();
    if (!activeSession) return;

    const updated = {
      ...activeSession,
      exercises: activeSession.exercises.map(ex =>
        ex.id === exerciseId ? { ...ex, sets: [...ex.sets, workoutSet] } : ex
      )
    };
    await db.sessions.put(updated);
    set({ activeSession: updated });
  },

  deleteSet: async (exerciseId, setId) => {
    const { activeSession } = get();
    if (!activeSession) return;

    const updated = {
      ...activeSession,
      exercises: activeSession.exercises.map(ex =>
        ex.id === exerciseId ? { ...ex, sets: ex.sets.filter(s => s.id !== setId) } : ex
      )
    };
    await db.sessions.put(updated);
    set({ activeSession: updated });
  },

  startRest: (seconds) => {
    set({ restTimer: { active: true, durationSec: seconds, endsAt: Date.now() + seconds * 1000 } });
  },

  stopRest: () => set({ restTimer: null })
}));

// ============================================================================
// 4. UI LAYER (React Components)
// ============================================================================

const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <div className={`bg-gray-800 rounded-xl border border-gray-700 shadow-xl overflow-hidden ${className}`}>
    {children}
  </div>
);

const Button = ({ children, onClick, variant = 'primary', className = '', disabled = false }: any) => {
  const base = "px-4 py-3 rounded-lg font-bold transition-all active:scale-95 flex items-center justify-center gap-2";
  const variants = {
    primary: "bg-blue-600 text-white hover:bg-blue-500",
    secondary: "bg-gray-700 text-white hover:bg-gray-600",
    danger: "bg-red-600/20 text-red-500 hover:bg-red-600/30",
    ghost: "bg-transparent text-gray-400 hover:text-white"
  };
  return (
    <button disabled={disabled} onClick={onClick} className={`${base} ${variants[variant]} ${disabled ? 'opacity-50 pointer-events-none' : ''} ${className}`}>
      {children}
    </button>
  );
};

const RestTimerOverlay = () => {
  const { restTimer, stopRest } = useStore();
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!restTimer?.active) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((restTimer.endsAt - Date.now()) / 1000));
      setTimeLeft(remaining);
      if (remaining <= 0) {
        stopRest();
        if (typeof window !== 'undefined' && 'vibrate' in navigator) navigator.vibrate([200, 100, 200]);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [restTimer, stopRest]);

  if (!restTimer?.active) return null;

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;

  return (
    <div className="fixed bottom-20 left-4 right-4 bg-blue-600 text-white p-4 rounded-xl shadow-2xl flex items-center justify-between z-50">
      <div className="flex items-center gap-3">
        <Clock className="w-6 h-6 animate-pulse" />
        <div>
          <p className="font-bold text-lg">Rest Time</p>
          <p className="text-blue-200 text-sm">Next set coming up</p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <span className="text-3xl font-mono font-bold tracking-tighter">
          {mins}:{secs.toString().padStart(2, '0')}
        </span>
        <button onClick={stopRest} className="p-2 bg-blue-700 rounded-full hover:bg-blue-800">
          <Square className="w-5 h-5" fill="currentColor" />
        </button>
      </div>
    </div>
  );
};

const SetLogger = ({ exercise, onLogSet }: { exercise: WorkoutExercise; onLogSet: (set: WorkoutSet) => void }) => {
  const [weight, setWeight] = useState<string>('');
  const [reps, setReps] = useState<string>('');
  const [isWarmup, setIsWarmup] = useState(false);

  const isRpsTemplate = exercise.templateSnapshot.type === 'RPS';
  const [rpsRounds, setRpsRounds] = useState<number[]>([]);
  const [rpsCurrentRep, setRpsCurrentRep] = useState('');

  const handleSave = () => {
    if (isRpsTemplate) {
      if (rpsRounds.length === 0 && !rpsCurrentRep) return;
      const rounds = [...rpsRounds];
      if (rpsCurrentRep) rounds.push(Number(rpsCurrentRep));

      onLogSet({
        id: generateId(),
        weight: Number(weight) || 0,
        reps: rounds.reduce((a, b) => a + b, 0),
        isFailure: true,
        isBackOff: false,
        type: 'RPS',
        rpsRounds: rounds.map(r => ({ reps: r })),
        timestamp: Date.now()
      });
      setRpsRounds([]);
      setRpsCurrentRep('');
    } else {
      if (!weight || !reps) return;
      onLogSet({
        id: generateId(),
        weight: Number(weight),
        reps: Number(reps),
        isFailure: !isWarmup,
        isBackOff: false,
        type: isWarmup ? 'Warmup' : 'Straight',
        timestamp: Date.now()
      });
      setReps('');
    }
  };

  const handleRpsRoundAdd = () => {
    if (!rpsCurrentRep) return;
    setRpsRounds([...rpsRounds, Number(rpsCurrentRep)]);
    setRpsCurrentRep('');
  };

  return (
    <div className="bg-gray-900 p-4 rounded-lg mt-3 space-y-3 border border-gray-700">
      <div className="flex justify-between items-center">
        <h4 className="font-bold text-gray-300 text-sm uppercase tracking-wider">Log New Set</h4>
        {!isRpsTemplate && (
          <button
            onClick={() => setIsWarmup(!isWarmup)}
            className={`text-xs px-2 py-1 rounded ${isWarmup ? 'bg-orange-500/20 text-orange-400' : 'bg-gray-700 text-gray-400'}`}
          >
            {isWarmup ? 'Warmup Set' : 'Working Set'}
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-gray-500 mb-1 block">Weight</label>
          <input
            type="number"
            value={weight}
            onChange={e => setWeight(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white text-center text-xl font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="0"
          />
        </div>

        {isRpsTemplate ? (
          <div>
            <label className="text-xs text-gray-500 mb-1 block">
              RPS Round {rpsRounds.length + 1}/3
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={rpsCurrentRep}
                onChange={e => setRpsCurrentRep(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white text-center text-xl font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Reps"
              />
              {rpsRounds.length < 2 && (
                <button onClick={handleRpsRoundAdd} className="bg-blue-600 px-3 rounded-lg text-white font-bold">+</button>
              )}
            </div>
          </div>
        ) : (
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Reps</label>
            <input
              type="number"
              value={reps}
              onChange={e => setReps(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white text-center text-xl font-bold focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="0"
            />
          </div>
        )}
      </div>

      {isRpsTemplate && rpsRounds.length > 0 && (
        <div className="flex gap-2 text-sm text-gray-400">
          Rounds: {rpsRounds.map((r, i) => <span key={i} className="bg-gray-800 px-2 rounded">{r}</span>)}
        </div>
      )}

      <Button onClick={handleSave} className="w-full py-4 mt-2" disabled={!weight || (!reps && !isRpsTemplate && !rpsCurrentRep)}>
        <CheckCircle className="w-5 h-5" /> Save Set
      </Button>
    </div>
  );
};

const HomeView = () => {
  const { startSession } = useStore();
  const [history, setHistory] = useState<WorkoutSession[]>([]);

  useEffect(() => {
    db.sessions.filter(s => !s.isDraft).reverse().limit(5).toArray().then(setHistory);
  }, []);

  return (
    <div className="space-y-6 pb-24">
      <header className="py-6">
        <h1 className="text-3xl font-black tracking-tight bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">
          BURKA OS
        </h1>
        <p className="text-gray-400 font-medium tracking-wide">The Bro Split 2.0 Engine</p>
      </header>

      <div className="space-y-4">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <Play className="w-5 h-5 text-blue-500" /> Start Session
        </h2>
        <div className="grid gap-3">
          {BRO_SPLIT_DAYS.map(day => (
            <button
              key={day.id}
              onClick={() => !day.isRest && startSession(day)}
              disabled={day.isRest}
              className={`w-full text-left p-4 rounded-xl border transition-all flex justify-between items-center
                ${day.isRest ? 'bg-gray-800/50 border-gray-800 opacity-50' : 'bg-gray-800 border-gray-700 hover:border-blue-500 active:scale-[0.98]'}`}
            >
              <div>
                <h3 className="font-bold text-lg">{day.name}</h3>
                <p className="text-sm text-gray-400 mt-1">
                  {day.isRest ? 'Recovery Day' : `${day.exercises.length} Exercises • ${day.priorityMuscles.join(', ')}`}
                </p>
              </div>
              {!day.isRest && <ChevronRight className="w-5 h-5 text-gray-500" />}
            </button>
          ))}
        </div>
      </div>

      <div className="pt-6">
        <h2 className="text-lg font-bold flex items-center gap-2 mb-4">
          <History className="w-5 h-5 text-gray-400" /> Recent Activity
        </h2>
        {history.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No sessions logged yet.</p>
        ) : (
          <div className="space-y-3">
            {history.map(session => (
              <div key={session.id} className="bg-gray-800 p-4 rounded-xl border border-gray-700 flex justify-between items-center">
                <div>
                  <p className="font-bold">{session.dayName}</p>
                  <p className="text-xs text-gray-400">{new Date(session.startedAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-blue-400">
                    {session.exercises.reduce((acc, ex) => acc + ex.sets.length, 0)} Sets
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const WorkoutView = () => {
  const { activeSession, logSet, deleteSet, endSession, cancelSession, startRest } = useStore();
  const [expandedEx, setExpandedEx] = useState<string | null>(null);

  if (!activeSession) return null;

  const handleLogSet = async (exId: string, setData: WorkoutSet) => {
    await logSet(exId, setData);
    startRest(120);
  };

  return (
    <div className="space-y-4 pb-32">
      <header className="sticky top-0 bg-gray-900/90 backdrop-blur-md z-40 py-4 border-b border-gray-800 flex justify-between items-center -mx-4 px-4">
        <div>
          <h2 className="font-black text-xl text-blue-400 uppercase tracking-wide">{activeSession.dayName}</h2>
          <p className="text-xs text-gray-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            Session Active (Autosaving)
          </p>
        </div>
        <Button variant="danger" onClick={() => { if (confirm('Cancel session? Data will be lost.')) cancelSession(); }}>
          Abort
        </Button>
      </header>

      <div className="space-y-4 pt-2">
        {activeSession.exercises.map((ex, index) => {
          const def = BURKA_EXERCISES[ex.definitionId];
          const isExpanded = expandedEx === ex.id;
          const workingSets = ex.sets.filter(s => s.type !== 'Warmup');
          const isComplete = workingSets.length >= ex.templateSnapshot.minSets;

          return (
            <Card key={ex.id} className={isExpanded ? 'border-blue-500/50' : ''}>
              <div
                className="p-4 cursor-pointer flex justify-between items-center"
                onClick={() => setExpandedEx(isExpanded ? null : ex.id)}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${isComplete ? 'bg-green-500/20 text-green-400' : 'bg-gray-700 text-gray-300'}`}>
                    {index + 1}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-tight">{def?.name || 'Unknown'}</h3>
                    <p className="text-xs text-gray-400 mt-1 flex items-center gap-2">
                      <span>{ex.templateSnapshot.minSets}-{ex.templateSnapshot.maxSets} x {ex.templateSnapshot.minReps}-{ex.templateSnapshot.maxReps}</span>
                      <span>•</span>
                      <span className="font-mono bg-gray-800 px-1 rounded">{ex.templateSnapshot.tempo}</span>
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-sm font-bold text-blue-400">{workingSets.length} / {ex.templateSnapshot.minSets}+</span>
                  {isComplete && <CheckCircle className="w-4 h-4 text-green-500" />}
                </div>
              </div>

              {isExpanded && (
                <div className="px-4 pb-4 pt-2 border-t border-gray-800 bg-gray-800/50">
                  {ex.sets.length > 0 && (
                    <div className="space-y-2 mb-4">
                      {ex.sets.map((setRow, idx) => (
                        <div key={setRow.id} className="flex justify-between items-center bg-gray-900 p-3 rounded-lg border border-gray-700">
                          <div className="flex items-center gap-3">
                            <span className="text-gray-500 text-xs w-4">{idx + 1}.</span>
                            <span className="font-bold text-lg">{setRow.weight} <span className="text-xs text-gray-500 font-normal">lbs</span></span>
                            <span className="text-gray-600">x</span>
                            <span className="font-bold text-lg">{setRow.reps} <span className="text-xs text-gray-500 font-normal">reps</span></span>
                            {setRow.type === 'Warmup' && <span className="text-[10px] bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded uppercase">WU</span>}
                            {setRow.type === 'RPS' && <span className="text-[10px] bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded uppercase">RPS</span>}
                          </div>
                          <button onClick={() => deleteSet(ex.id, setRow.id)} className="p-2 text-gray-500 hover:text-red-400">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <SetLogger exercise={ex} onLogSet={(setRow) => handleLogSet(ex.id, setRow)} />

                  {workingSets.length > 0 && (
                    <div className="mt-4 p-3 bg-blue-900/20 border border-blue-800/50 rounded-lg flex items-start gap-2">
                      <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-blue-300">
                        {ProgressionEngine.analyzeSet(
                          workingSets[workingSets.length - 1].reps,
                          ex.templateSnapshot.maxReps,
                          ex.templateSnapshot.minReps,
                          workingSets[workingSets.length - 1].isFailure
                        ).reason}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <div className="pt-8">
        <Button onClick={endSession} className="w-full py-5 text-lg shadow-lg shadow-blue-600/20">
          <Save className="w-6 h-6" /> Finish & Save Workout
        </Button>
      </div>
    </div>
  );
};

const HistoryView = () => {
  const [sessions, setSessions] = useState<WorkoutSession[]>([]);

  useEffect(() => {
    db.sessions.filter(s => !s.isDraft).toArray().then(data => {
      setSessions(data.sort((a, b) => b.startedAt - a.startedAt));
    });
  }, []);

  const chartData = useMemo(() => {
    return sessions.slice(0, 10).reverse().map(s => {
      const vol = s.exercises.reduce((acc, ex) => {
        return acc + ex.sets.filter(setRow => setRow.type !== 'Warmup').reduce((v, setRow) => v + (setRow.weight * setRow.reps), 0);
      }, 0);
      return {
        date: new Date(s.startedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        volume: vol
      };
    });
  }, [sessions]);

  return (
    <div className="space-y-6 pb-24">
      <header className="py-6 border-b border-gray-800">
        <h1 className="text-2xl font-black">Training History</h1>
      </header>

      {chartData.length > 1 && (
        <Card className="p-4">
          <h3 className="text-sm font-bold text-gray-400 mb-4 uppercase tracking-wider">Volume Trend</h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Line type="monotone" dataKey="volume" stroke="#3B82F6" strokeWidth={3} dot={false} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <div className="space-y-4">
        {sessions.map(session => (
          <Card key={session.id} className="p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-bold text-lg">{session.dayName}</h3>
                <p className="text-xs text-gray-400">{new Date(session.startedAt).toLocaleString()}</p>
              </div>
              <div className="bg-gray-900 px-3 py-1 rounded-full text-xs font-bold text-blue-400 border border-gray-700">
                {session.finishedAt ? Math.round((session.finishedAt - session.startedAt) / 60000) : 0} mins
              </div>
            </div>

            <div className="space-y-2 mt-4">
              {session.exercises.map(ex => {
                const def = BURKA_EXERCISES[ex.definitionId];
                const workingSets = ex.sets.filter(s => s.type !== 'Warmup');
                if (workingSets.length === 0) return null;

                const topSet = [...workingSets].sort((a, b) => b.weight - a.weight)[0];

                return (
                  <div key={ex.id} className="text-sm flex justify-between items-center border-t border-gray-800 pt-2">
                    <span className="text-gray-300 truncate pr-4">{def?.name}</span>
                    <span className="font-mono text-gray-400 whitespace-nowrap">
                      {workingSets.length} sets • Top: <strong className="text-white">{topSet.weight}x{topSet.reps}</strong>
                    </span>
                  </div>
                );
              })}
            </div>
          </Card>
        ))}
        {sessions.length === 0 && <p className="text-gray-500 text-center">No history yet.</p>}
      </div>
    </div>
  );
};

const SettingsView = () => {
  const handleExport = async () => {
    const data = {
      version: 1,
      sessions: await db.sessions.toArray(),
      settings: await db.settings.toArray(),
      videoMappings: await db.videoMappings.toArray()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BurkaOS_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const parsed = ExportSchema.parse(json);

        await db.transaction('rw', db.sessions, db.settings, db.videoMappings, async () => {
          await db.sessions.clear();
          await db.settings.clear();
          await db.videoMappings.clear();

          if (parsed.sessions.length) await db.sessions.bulkAdd(parsed.sessions as any[]);
          if (parsed.settings.length) await db.settings.bulkAdd(parsed.settings as any[]);
          if (parsed.videoMappings.length) await db.videoMappings.bulkAdd(parsed.videoMappings as any[]);
        });

        alert('Imported successfully!');
        window.location.reload();
      } catch (err) {
        alert('Invalid backup file format.');
        console.error(err);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-24">
      <header className="py-6 border-b border-gray-800">
        <h1 className="text-2xl font-black">System Settings</h1>
      </header>

      <Card className="p-5 space-y-4">
        <h3 className="font-bold flex items-center gap-2"><Download className="w-5 h-5 text-blue-400" /> Data Management</h3>
        <p className="text-sm text-gray-400">All data is stored locally on this device. Export weekly as a backup.</p>

        <div className="grid grid-cols-2 gap-3 pt-2">
          <Button variant="secondary" onClick={handleExport}>
            <Download className="w-4 h-4" /> Export
          </Button>
          <label className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-bold transition-all active:scale-95 bg-gray-700 text-white hover:bg-gray-600 cursor-pointer">
            <Upload className="w-4 h-4" /> Import
            <input type="file" accept=".json" className="hidden" onChange={handleImport} />
          </label>
        </div>
      </Card>

      <Card className="p-5 space-y-4 opacity-50">
        <h3 className="font-bold flex items-center gap-2"><Youtube className="w-5 h-5 text-red-500" /> YouTube (Coming Soon)</h3>
        <p className="text-sm text-gray-400">Later: paste API key to auto-map playlist videos.</p>
        <input disabled type="text" placeholder="AIzaSy..." className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 text-white text-sm" />
      </Card>

      <div className="text-center text-xs text-gray-600 mt-8">
        <p>BurkaOS Engine v0.1</p>
        <p>Local DB Schema v1</p>
      </div>
    </div>
  );
};

export default function BurkaOSApp() {
  const { view, setView, activeSession, resumeSession } = useStore();
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const drafts = await db.sessions.filter(s => s.isDraft).toArray();
      if (drafts.length > 0) {
        resumeSession(drafts.sort((a, b) => b.startedAt - a.startedAt)[0]);
        setView('WORKOUT');
      }
      setIsLoaded(true);
    };
    init();
  }, [resumeSession, setView]);

  if (!isLoaded) {
    return <div className="min-h-screen bg-gray-950 flex items-center justify-center text-blue-500 animate-pulse font-bold">BOOTING SYSTEM...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans selection:bg-blue-500/30">
      <div className="max-w-md mx-auto w-full min-h-screen relative shadow-2xl bg-gray-900/30 overflow-x-hidden">
        <main className="px-4">
          {view === 'HOME' && <HomeView />}
          {view === 'WORKOUT' && <WorkoutView />}
          {view === 'HISTORY' && <HistoryView />}
          {view === 'SETTINGS' && <SettingsView />}
        </main>

        <RestTimerOverlay />

        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-gray-900/90 backdrop-blur-xl border-t border-gray-800 z-40 pb-safe">
          <div className="flex justify-around items-center p-2">
            {[
              { id: 'HOME', icon: Dumbbell, label: 'Train' },
              { id: 'HISTORY', icon: History, label: 'History' },
              { id: 'SETTINGS', icon: Settings, label: 'Settings' }
            ].map(item => {
              const isActive = view === item.id || (item.id === 'HOME' && view === 'WORKOUT');
              return (
                <button
                  key={item.id}
                  onClick={() => setView(item.id as any)}
                  className={`flex flex-col items-center p-2 rounded-xl transition-all duration-300 w-20
                    ${isActive ? 'text-blue-400' : 'text-gray-500 hover:text-gray-300'}`}
                >
                  <item.icon className="w-6 h-6 mb-1" />
                  <span className="text-[10px] font-bold tracking-wider">{item.label}</span>
                  {item.id === 'HOME' && activeSession && !isActive && (
                    <span className="absolute top-2 right-6 w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .pb-safe { padding-bottom: env(safe-area-inset-bottom, 1rem); }
      ` }} />
    </div>
  );
}
