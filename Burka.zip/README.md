# BurkaOS

Offline-first PWA workout tracker (Bro Split 2.0).

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Build

```bash
npm run build
npm start
```

## Deploy to Vercel

1. Push this repo to GitHub.
2. In Vercel: **New Project** → Import repo → Deploy.
3. On iPhone: open the deployed URL in Safari → Share → **Add to Home Screen**.

## Notes

- All data is stored locally in IndexedDB on your device.
- Use **Settings → Export** weekly to back up your data.
