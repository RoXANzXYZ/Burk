import BurkaOSApp from "@/components/BurkaOSApp";

export default function Page() {
  return <BurkaOSApp />;
}
